Change the OpenBlas library location in makefile appropriate to your machine. 
Type make in terminal to get the executable file.  
lenet usage:
% ./main lenet input_file conv1_file conv2_file fc1_file fc2_file

input_file is the processed input image stored in txt file. Ex MNISTexampledigit1/1/data.txt
It outputs top 5 predicted classes along with their probabilities. 

Latex report is in report folder. Image files are also there.

